
## Test
#python run_pretraining.py --mask 0.6 --gau 0.25 --vf 0.25 --hf 0.0 --hs 0.0 --data CWRU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 10 --save_ckpt_freq 10
#python run_linprobe.py --checkpoints_idx 9 --source CWRU --data CWRU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 10 --save_ckpt_freq 10
#python run_finetuning.py --checkpoints_idx 9 --source CWRU --data CWRU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 10 --save_ckpt_freq 10


## CWRU - pre_training
#python run_pretraining.py --mask 0.6 --gau 0.25 --vf 0.25 --hf 0.0 --hs 0.0 --data CWRU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 1600 --save_ckpt_freq 20


## CWRU -> CWRU
#python run_linprobe.py --checkpoints_idx 799 --source CWRU --data CWRU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#python run_finetuning.py --checkpoints_idx 799 --source CWRU --data CWRU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10


## -------------------CWRU------------------------------
## CWRU -> JNU
#python run_linprobe.py --checkpoints_idx 799 --source CWRU --data JNU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#python run_finetuning.py --checkpoints_idx 799 --source CWRU --data JNU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#
## CWRU -> MFPT
#python run_linprobe.py --checkpoints_idx 799 --source CWRU --data MFPT --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#python run_finetuning.py --checkpoints_idx 799 --source CWRU --data MFPT --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#
## CWRU -> XJTU
#python run_linprobe.py --checkpoints_idx 799 --source CWRU --data XJTU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#python run_finetuning.py --checkpoints_idx 799 --source CWRU --data XJTU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10

## CWRU -> ECG
#python run_linprobe.py --checkpoints_idx 799 --source CWRU --data ECG --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#python run_finetuning.py --checkpoints_idx 799 --source CWRU --data ECG --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#
## CWRU -> EMG
#python run_linprobe.py --checkpoints_idx 799 --source CWRU --data EMG --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#python run_finetuning.py --checkpoints_idx 799 --source CWRU --data EMG --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10

## ECG - pre_training
#python run_pretraining.py --mask 0.6 --gau 0.25 --vf 0.25 --hf 0.0 --hs 0.0 --data ECG --series_length 1024 --model tst_small_patch32_1024_origin --epochs 800 --save_ckpt_freq 20


## -------------------ECG------------------------------
### ECG -> CWRU
#python run_linprobe.py --checkpoints_idx 799 --source ECG --data CWRU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#python run_finetuning.py --checkpoints_idx 799 --source ECG --data CWRU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#
## ECG -> JNU
#python run_linprobe.py --checkpoints_idx 799 --source ECG --data JNU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#python run_finetuning.py --checkpoints_idx 799 --source ECG --data JNU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#
## ECG -> MFPT
#python run_linprobe.py --checkpoints_idx 799 --source ECG --data MFPT --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#python run_finetuning.py --checkpoints_idx 799 --source ECG --data MFPT --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#
## ECG -> XJTU
#python run_linprobe.py --checkpoints_idx 799 --source ECG --data XJTU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#python run_finetuning.py --checkpoints_idx 799 --source ECG --data XJTU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10

## ECG -> EMG
#python run_linprobe.py --checkpoints_idx 799 --source ECG --data EMG --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#python run_finetuning.py --checkpoints_idx 799 --source ECG --data EMG --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10


### MFPT - pre_training
#python run_pretraining.py --mask 0.6 --gau 0.25 --vf 0.25 --hf 0.0 --hs 0.0 --data MFPT --series_length 1024 --model tst_small_patch32_1024_origin --epochs 800 --save_ckpt_freq 20
#
### MFPT -> MFPT
#python run_linprobe.py --checkpoints_idx 799 --source MFPT --data MFPT --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#python run_finetuning.py --checkpoints_idx 799 --source MFPT --data MFPT --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10

### XJTU - pre_training
#python run_pretraining.py --mask 0.6 --gau 0.25 --vf 0.25 --hf 0.0 --hs 0.0 --data XJTU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 800 --save_ckpt_freq 20

### XJTU -> XJTU
#python run_linprobe.py --checkpoints_idx 799 --source XJTU --data XJTU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#python run_finetuning.py --checkpoints_idx 799 --source XJTU --data XJTU --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10

## ECG -> ECG
#python run_linprobe.py --checkpoints_idx 799 --source ECG --data ECG --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10
#python run_finetuning.py --checkpoints_idx 799 --source ECG --data ECG --series_length 1024 --model tst_small_patch32_1024_origin --epochs 50 --save_ckpt_freq 10

## ECG - pre_training
python run_pretraining.py --mask 0.6 --gau 0.25 --vf 0.25 --hf 0.0 --hs 0.0 --data ECG --series_length 1472 --model tst_small_patch32_1472 --epochs 800 --save_ckpt_freq 20

## MFPT -> MFPT
python run_linprobe.py --checkpoints_idx 799 --source ECG --data ECG --series_length 1472 --model tst_small_patch32_1472 --epochs 50 --save_ckpt_freq 10
python run_finetuning.py --checkpoints_idx 799 --source ECG --data ECG --series_length 1472 --model tst_small_patch32_1472 --epochs 50 --save_ckpt_freq 10

