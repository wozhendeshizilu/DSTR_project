import os
import json
import time
import torch
import argparse
import datetime
import numpy as np
from pathlib import Path
from collections import OrderedDict
import torch.backends.cudnn as cudnn
import sys
sys.path.append('../../')


from timm.utils import ModelEma
from timm.models import create_model
from optim_factory import create_optimizer, LayerDecayValueAssigner

import utils
import datasets
from utils import NativeScalerWithGradNormCount as NativeScaler
from engine_for_finetuning import train_one_epoch, validation_one_epoch, final_test, merge
import datasets.transform as T
from modules.classifier import TSeriesClassifier
from torch.utils.data import ConcatDataset


def get_args():
    parser = argparse.ArgumentParser('TSeries fine-tuning and evaluation script for video classification', add_help=False)

    parser.add_argument('--epochs', default=200, type=int)
    parser.add_argument('--start_epoch', default=0, type=int, metavar='N',
                        help='start epoch')
    parser.add_argument('--batch_size', default=64, type=int)
    parser.add_argument('--update_freq', default=1, type=int)
    parser.add_argument('--save_ckpt_freq', default=10, type=int)
    parser.add_argument('--nb_workers', default=0, type=int)

    # ---------------------------------------------------------------------------------------------------------------
    # dataset Augmentation
    parser.add_argument('--snr', type=float, default=25., metavar='M', help='gaussian noise')
    parser.add_argument('--mask_ratio', default=0.5, type=float,  help='ratio of the visual tokens/patches need be masked')
    parser.add_argument('--gau', default=0.0, type=float, metavar='M', help='gaussian noise')
    parser.add_argument('--vf', default=0.0, type=float,  help='ratio of the visual tokens/patches need be masked')
    parser.add_argument('--hf', default=0.0, type=float,  help='ratio of the visual tokens/patches need be masked')
    parser.add_argument('--hs', default=0.0, type=float,  help='ratio of the visual tokens/patches need be masked')

    # Dataset parameters
    parser.add_argument('--data', default='CWRU', choices=utils.get_dataset_names(),
                        type=str, help='dataset choices: Epilepsy, FD_B, Gesture, EMG')
    parser.add_argument('--checkpoints_idx', default=799, type=int)
    parser.add_argument('--root', default=None, type=str, help='root path of dataset')
    parser.add_argument('--series_length', default=1024, type=int)
    parser.add_argument('--dataset_split', default=None, type=tuple, help='dataset path for evaluation')

    # Model parameters
    parser.add_argument('--model', default='tst_small_patch32_1024_origin', type=str, metavar='MODEL',
                        help='Name of model to train')
    parser.add_argument('--fc_drop_rate', type=float, default=0.0, metavar='PCT', help='Dropout rate (default: 0.)')
    parser.add_argument('--drop', type=float, default=0.0, metavar='PCT', help='Dropout rate (default: 0.)')
    parser.add_argument('--attn_drop_rate', type=float, default=0.0, metavar='PCT', help='Attention dropout rate (default: 0.)')
    parser.add_argument('--drop_path',  type=float, default=0.1, metavar='PCT', help='Drop path rate (default: 0.1)')

    # ---------------------------------------------------------------------------------------------------------------

    # Finetuning params
    parser.add_argument('--model_key', default='model|module', type=str, help='key to acquire pre_training checkpoint')
    parser.add_argument('--model_prefix', default='', type=str, help='prefix when load checkpoint')
    parser.add_argument('--init_scale', default=0.001, type=float, help='init_scale')
    parser.add_argument('--use_checkpoint', action='store_true')
    parser.set_defaults(use_checkpoint=False)
    parser.add_argument('--use_mean_pooling', action='store_true')
    parser.set_defaults(use_mean_pooling=True)
    parser.add_argument('--use_cls', action='store_false', dest='use_mean_pooling')

    # train config
    parser.add_argument('--disable_eval_during_finetuning', action='store_true', default=False)
    parser.add_argument('--model_ema', action='store_true', default=False)
    parser.add_argument('--model_ema_decay', type=float, default=0.9999, help='')
    parser.add_argument('--model_ema_force_cpu', action='store_true', default=False, help='')

    # Optimizer parameters
    parser.add_argument('--opt', default='adamw', type=str, metavar='OPTIMIZER',
                        help='Optimizer (default: "adamw"')
    parser.add_argument('--opt_eps', default=1e-8, type=float, metavar='EPSILON',
                        help='Optimizer Epsilon (default: 1e-8)')
    parser.add_argument('--opt_betas', default=(0.9, 0.999), type=tuple, nargs='+', metavar='BETA',
                        help='Optimizer Betas (default: None, use opt default)')
    parser.add_argument('--clip_grad', type=float, default=None, metavar='NORM',
                        help='Clip gradient norm (default: None, no clipping)')
    parser.add_argument('--momentum', type=float, default=0.9, metavar='M',
                        help='SGD momentum (default: 0.9)')
    parser.add_argument('--weight_decay', type=float, default=0.05,
                        help='weight decay (default: 0.05)')
    parser.add_argument('--weight_decay_end', type=float, default=None, help="""Final value of the
        weight decay. We use a cosine schedule for WD and using a larger decay by
        the end of training improves performance for ViTs.""")

    parser.add_argument('--lr', type=float, default=1e-3, metavar='LR',
                        help='learning rate (default: 1e-3)')
    parser.add_argument('--layer_decay', type=float, default=0.75)
    parser.add_argument('--warmup_lr', type=float, default=1e-6, metavar='LR',
                        help='warmup learning rate (default: 1e-6)')
    parser.add_argument('--min_lr', type=float, default=1e-6, metavar='LR',
                        help='lower lr bound for cyclic schedulers that hit 0 (1e-5)')
    parser.add_argument('--warmup_epochs', type=int, default=5, metavar='N',
                        help='epochs to warmup LR, if scheduler supports')
    parser.add_argument('--warmup_steps', type=int, default=-1, metavar='N',
                        help='nb of steps to warmup LR, will overload warmup_epochs if set > 0')

    # fixed
    parser.add_argument('--seed', default=0, type=int)
    parser.add_argument('--resume', default='', help='resume from checkpoint')
    parser.add_argument('--auto_resume', action='store_true')
    parser.set_defaults(auto_resume=True)
    parser.add_argument('--no_auto_resume', action='store_false', dest='auto_resume')
    parser.add_argument('--save_ckpt', action='store_true')
    parser.set_defaults(save_ckpt=True)
    parser.add_argument('--no_save_ckpt', action='store_false', dest='save_ckpt')

    parser.add_argument('--eval', action='store_true', help='Perform evaluation only')
    parser.set_defaults(eval=True)
    parser.add_argument('--dist_eval', action='store_true', default=False, help='Enabling distributed evaluation')
    parser.add_argument('--pin_mem', action='store_true',
                        help='Pin CPU memory in DataLoader for more efficient (sometimes) transfer to GPU.')
    parser.add_argument('--no_pin_mem', action='store_false', dest='pin_mem')
    parser.set_defaults(pin_mem=True)

    # logs
    parser.add_argument('--output_dir', default='./logs/supervised/{}/{}/checkpoints',
                        help='path to save ssl_checkpoints, empty for no saving')
    known_args, _ = parser.parse_known_args()

    return parser.parse_args(), None


def get_model(args):
    print(f"Creating model: {args.model}")
    model = create_model(
        args.model,
        fc_drop_rate=args.fc_drop_rate,
        drop_rate=args.drop,
        drop_path_rate=args.drop_path,
        attn_drop_rate=args.attn_drop_rate,
        drop_block_rate=None,
        use_checkpoint=args.use_checkpoint,
        use_mean_pooling=args.use_mean_pooling,
        init_scale=args.init_scale,
    )
    return model


def main(args, ds_init):
    print(args)
    device = args.device

    # fix the seed for reproducibility
    seed = args.seed + utils.get_rank()
    torch.manual_seed(seed)
    np.random.seed(seed)
    # random.seed(seed)

    cudnn.benchmark = True

    # transform
    dataset = datasets.__dict__[args.data]
    transform_train = transform_test = transform_val = T.Compose([
        T.CenterResize(args.series_length),
        T.Normalization(),
    ])
    dataset_train = dataset(mode='train', transform=transform_train, shuffle=True)
    dataset_val = dataset(mode='val', transform=transform_val, shuffle=True)
    dataset_test = dataset(mode='test', transform=transform_test, shuffle=True)
    args.num_classes = len(dataset_train.CLASSES)

    collate_func = None

    data_loader_train = torch.utils.data.DataLoader(
        dataset_train,
        batch_size=args.batch_size,
        num_workers=args.nb_workers,
        pin_memory=args.pin_mem,
        drop_last=True,
        collate_fn=collate_func,
    )

    if dataset_val is not None:
        data_loader_val = torch.utils.data.DataLoader(
            dataset_val,
            batch_size=args.batch_size,
            num_workers=args.nb_workers,
            pin_memory=args.pin_mem,
            drop_last=False
        )
    else:
        data_loader_val = None

    if dataset_test is not None:
        data_loader_test = torch.utils.data.DataLoader(
            dataset_test,
            batch_size=args.batch_size,
            num_workers=args.nb_workers,
            pin_memory=args.pin_mem,
            drop_last=False
        )
    else:
        data_loader_test = None

    model = get_model(args)
    model.reset_classifier(0, global_pool='')
    classifier = TSeriesClassifier(model, args.num_classes).to(device)

    model_ema = None
    if args.model_ema:
        model_ema = ModelEma(
            classifier,
            decay=args.model_ema_decay,
            device='cpu' if args.model_ema_force_cpu else '',
            resume='')
        print("Using EMA with decay = %.8f" % args.model_ema_decay)

    model_without_ddp = classifier
    n_parameters = sum(p.numel() for p in classifier.parameters() if p.requires_grad)

    print("Model = %s" % str(model_without_ddp))
    print('nbber of params:', n_parameters)

    total_batch_size = args.batch_size
    nb_training_steps_per_epoch = len(dataset_train) // total_batch_size
    args.lr = args.lr * total_batch_size / 256
    args.min_lr = args.min_lr * total_batch_size / 256
    args.warmup_lr = args.warmup_lr * total_batch_size / 256
    print("LR = %.8f" % args.lr)
    print("Batch size = %d" % total_batch_size)
    print("Update frequent = %d" % args.update_freq)
    print("nbber of training examples = %d" % len(dataset_train))
    print("nbber of training training per epoch = %d" % nb_training_steps_per_epoch)

    nb_layers = model_without_ddp.get_num_layers()
    if args.layer_decay < 1.0:
        assigner = LayerDecayValueAssigner(
            list(args.layer_decay ** (nb_layers + 1 - i) for i in range(nb_layers + 2)))
    else:
        assigner = None

    if assigner is not None:
        print("Assigned values = %s" % str(assigner.values))

    skip_weight_decay_list = model.no_weight_decay()
    print("Skip weight decay list: ", skip_weight_decay_list)

    optimizer = create_optimizer(
        args, model_without_ddp, skip_list=skip_weight_decay_list,
        get_num_layer=assigner.get_layer_id if assigner is not None else None,
        get_layer_scale=assigner.get_scale if assigner is not None else None)
    loss_scaler = NativeScaler()

    print("Use step level LR scheduler!")
    lr_schedule_values = utils.cosine_scheduler(
        args.lr, args.min_lr, args.epochs, nb_training_steps_per_epoch,
        warmup_epochs=args.warmup_epochs, warmup_steps=args.warmup_steps,
    )
    if args.weight_decay_end is None:
        args.weight_decay_end = args.weight_decay
    wd_schedule_values = utils.cosine_scheduler(
        args.weight_decay, args.weight_decay_end, args.epochs, nb_training_steps_per_epoch)
    print("Max WD = %.7f, Min WD = %.7f" % (max(wd_schedule_values), min(wd_schedule_values)))

    criterion = torch.nn.CrossEntropyLoss()

    print("criterion = %s" % str(criterion))
    utils.auto_load_model(
        args=args, model=classifier, model_without_ddp=model_without_ddp,
        optimizer=optimizer, loss_scaler=loss_scaler, model_ema=model_ema)

    global_rank = utils.get_rank()
    preds_file = os.path.join(args.output_dir, 'log.txt')
    if args.eval:
        total_acc, total_auc, total_prc, trgs, performance = \
            utils.validate_metrics(data_loader_test, classifier, args, device)
        with open(os.path.join(args.output_dir, 'log_eval.txt'), mode="a", encoding="utf-8") as f:
            f.write(json.dumps(performance) + "\n")

        exit(0)

    print(f"Start training for {args.epochs} epochs")
    start_time = time.time()
    max_acc1 = 0.0
    for epoch in range(args.start_epoch, args.epochs):
        train_stats = train_one_epoch(
            classifier, criterion, data_loader_train, optimizer,
            device, epoch, loss_scaler, args.clip_grad, model_ema,
            start_steps=epoch * nb_training_steps_per_epoch,
            lr_schedule_values=lr_schedule_values, wd_schedule_values=wd_schedule_values,
            num_training_steps_per_epoch=nb_training_steps_per_epoch, update_freq=args.update_freq,
        )
        if args.output_dir and args.save_ckpt:
            if (epoch + 1) % args.save_ckpt_freq == 0 or epoch + 1 == args.epochs:
                utils.save_model(
                    args=args, model=classifier, model_without_ddp=model_without_ddp, optimizer=optimizer,
                    loss_scaler=loss_scaler, epoch=epoch, model_ema=model_ema)
        if data_loader_val is not None:
            val_stats = validation_one_epoch(data_loader_val, classifier, device)
            print(f"Accuracy of the network on the {len(dataset_val)} val videos: {val_stats['acc1']:.1f}%")
            if max_acc1 < val_stats["acc1"]:
                max_acc1 = val_stats["acc1"]
                if args.output_dir and args.save_ckpt:
                    utils.save_model(
                        args=args, model=classifier, model_without_ddp=model_without_ddp, optimizer=optimizer,
                        loss_scaler=loss_scaler, epoch="best", model_ema=model_ema)

            print(f'Max accuracy: {max_acc1:.2f}%')

            log_stats = {**{f'train_{k}': v for k, v in train_stats.items()},
                         **{f'val_{k}': v for k, v in val_stats.items()},
                         'epoch': epoch,
                         'n_parameters': n_parameters}
        else:
            log_stats = {**{f'train_{k}': v for k, v in train_stats.items()},
                         'epoch': epoch,
                         'n_parameters': n_parameters}
        if args.output_dir and utils.is_main_process():
            with open(preds_file, mode="a", encoding="utf-8") as f:
                f.write(json.dumps(log_stats) + "\n")

        if (epoch + 1) % args.save_ckpt_freq == 0:
            test_stats = final_test(data_loader_test, classifier, device, preds_file)

    classifier.load_state_dict(torch.load(os.path.join(args.output_dir, "checkpoint-%s.pth" % 'best'))['model'])
    test_stats = final_test(data_loader_test, classifier, device, preds_file)

    total_time = time.time() - start_time
    total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    print('Training time {}'.format(total_time_str))


if __name__ == '__main__':
    opts, ds_init = get_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    opts.device = device
    if opts.output_dir:
        opts.output_dir = opts.output_dir.format(opts.data.lower(), opts.model)
        Path(opts.output_dir).mkdir(parents=True, exist_ok=True)
    main(opts, ds_init)
