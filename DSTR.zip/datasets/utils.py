import os
import pandas as pd
import glob
import errno
import random
import urllib.request as request
import numpy as np
from scipy.io import loadmat
from glob import glob
from pathlib2 import Path
import torch


def load_and_slice_data_from_mat(f: str, lab: int, slice_length: int, hop_size: int) -> tuple[
    torch.Tensor, torch.Tensor]:
    x = np.zeros((0, slice_length))
    y = np.zeros((0), dtype=np.longlong)

    # directory of this file
    mat_dict = loadmat(f)
    key = list(filter(lambda x: 'DE_time' in x, mat_dict.keys()))[0]
    time_series = mat_dict[key][:, 0]

    idx_last = -(time_series.shape[0] % slice_length)
    clips = time_series[:idx_last].reshape(-1, slice_length)

    n = clips.shape[0]
    x = torch.from_numpy(np.vstack((x, clips))).type(torch.float)
    y = torch.from_numpy(np.hstack((y, np.full(n, lab, dtype=np.longlong))))
    return x, y


def search_files(root: str, pref: str) -> list:
    root = Path(root)
    files = glob(str(root / pref), recursive=True)
    return files


def load_and_slice_data_from_csv(f, lab, slice_length, hop_size) -> tuple[torch.Tensor, torch.Tensor]:
    samples = []
    _data = np.loadtxt(f)
    l_idx = 0
    while (l_idx + slice_length < _data.size):
        samples.append(_data[l_idx: l_idx + slice_length])
        l_idx += hop_size
    return torch.from_numpy(np.vstack(samples)).type(torch.float), torch.full((len(samples),), lab, dtype=torch.long)


def load_har(root=r'D:\repository\pycharm\datasets\time series\HAR\UCI HAR Dataset'):
    signal_class = [
        'body_acc_x_',
        'body_acc_y_',
        'body_acc_z_',
        'body_gyro_x_',
        'body_gyro_x_',
        'body_gyro_x_',
        'total_acc_x_',
        'total_acc_y_',
        'total_acc_z_',
    ]

    def xload(X_path):
        x = []
        for each in X_path:
            with open(each, 'r') as f:
                x.append(np.array([eachline.replace('  ', ' ').strip().split(' ') for eachline in f], dtype=np.float32))
        x = np.transpose(x, (1, 2, 0))
        return x

    def yload(Y_path):
        y = pd.read_csv(Y_path, header=None).to_numpy().reshape(-1)
        return y - 1  # label从0开始

    X_train_path = [root + '/train/Inertial Signals/' + signal + 'train.txt' for signal in signal_class]
    X_test_path = [root + '/test/Inertial Signals/' + signal + 'test.txt' for signal in signal_class]
    Y_train_path = root + '/train/y_train.txt'
    Y_test_path = root + '/test/y_test.txt'

    X_train = xload(X_train_path)
    X_test = xload(X_test_path)
    Y_train = yload(Y_train_path)
    Y_test = yload(Y_test_path)
    samples, targets = np.concatenate((X_train, X_test), axis=0), np.concatenate((Y_train, Y_test), axis=0)
    samples, targets = torch.from_numpy(samples).permute(0, 2, 1), torch.from_numpy(targets)
    return samples, targets
