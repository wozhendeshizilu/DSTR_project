import torch
from torch.utils.data import TensorDataset


class TSeriesDataset(TensorDataset):
    def __init__(self, x: torch.Tensor, y: torch.Tensor, transform=None, tgt_transform=None, shuffle=True,
                 nb_aug=1) -> None:
        # 定义初始化方法，接收x和y两个张量，以及变换、打乱和增强等参数
        super(TSeriesDataset, self).__init__(x, y)
        # 调用父类的初始化方法
        self.transform = transform
        self.tgt_transform = tgt_transform
        self.series_length = x.shape[-1]
        self.nb_channel = x.shape[-2]
        self.aug_total = nb_aug
        if shuffle:
            self._shuffle()

    def __getitem__(self, _idx) -> []:
        samples, targets = self.tensors
        ret = []
        sample, target = samples[_idx], targets[_idx]
        if self.transform:
            for _ in range(self.aug_total):
                ret += [self.transform(sample)]
        else:
            ret += [sample]
        if self.tgt_transform:
            target = self.tgt_transform(target)
        ret += [target]
        return ret

    def _shuffle(self) -> None:
        samples, targets = self.tensors
        idx = torch.randperm(samples.shape[0])
        self.tensors = (samples[idx, :], targets[idx])
