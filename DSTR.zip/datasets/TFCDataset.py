"""
@author: Junguang Jiang
@contact: JiangJunguang1123@outlook.com
"""
import os
import torch
import numpy as np
from .SensorDataset import TSeriesDataset

__all__ = ['SleepEEG', 'Epilepsy', 'FD_A', 'FD_B', 'HAR', 'Gesture', 'EMG', 'ECG']


class TFCDataset(TSeriesDataset):
    # https://arxiv.org/abs/2206.08496
    f_list = ['train.pt', 'val.pt', 'test.pt']

    def __init__(self, root: str, mode=None, series_length=None, subset=False, **kwargs):
        assert mode in 'train' or 'test' or 'val', f'{mode} is not acceptable'
        f = os.path.join(root, f'{mode}.pt')
        _data = torch.load(f)
        _x, _y = _data["samples"], _data["labels"]
        if isinstance(_x, np.ndarray):
            _x = torch.from_numpy(_x)

        if isinstance(_y, np.ndarray):
            _y = torch.from_numpy(_y)

        if len(_x.shape) < 3:
            _x = _x.unsqueeze(2)

        if _x.shape.index(min(_x.shape)) != 1:  # make sure the Channels in second dim
            _x = _x.permute(0, 2, 1)

        # Align the TS length between source and target datasets
        _x = _x[..., :int(series_length)].type(torch.float32)
        _y = _y.type(torch.long)

        # subset
        if subset:
            _x = _x[:4000]
            _y = _y[:4000]

        super(TFCDataset, self).__init__(_x, _y, **kwargs)


class SleepEEG(TFCDataset):
    description = '''
    (1). SleepEEG contains 153 whole-night sleeping Electroencephalography (EEG) recordings that are 
    monitored by sleep cassette. The data is collected from 82 healthy subjects. The 1-lead EEG signal 
    is sampled at 100 Hz. We segment the EEG signals into segments (window size is 200) without overlapping
    and each segment forms a sample. Every sample is associated with one of the five sleeping patterns/stages: 
    Wake (W), Non-rapid eye movement (N1, N2, N3) and Rapid Eye Movement (REM). After segmentation,
    we have 371,055 EEG samples. The raw dataset is distributed under the Open Data Commons Attribution License v1.0.

    '''
    TSeries_length = 178
    NB_channel = 1
    CLASSES = ['Wake (W)', 'Non-rapid eye movement (N1)', 'Non-rapid eye movement (N2)', 'Non-rapid eye movement (N3)',
               'Rapid Eye Movement (REM)']

    def __init__(self, root=r'D:\repository\pycharm\datasets\time series\SleepEEG', mode='train', **kwargs):
        super(SleepEEG, self).__init__(root=root, mode=mode, series_length=SleepEEG.TSeries_length, **kwargs)
        self.classes = SleepEEG.CLASSES


class Epilepsy(TFCDataset):
    description = '''
    Epilepsy contains single-channel EEG measurements from 500 subjects. For each subject, 
    the brain activity was recorded for 23.6 seconds. The dataset was then divided and shuffled 
    (to mitigate sample-subject association) into 11,500 samples of 1 second each, sampled at 178 Hz. 
    The raw dataset features 5 different classification labels corresponding to different status of 
    the subject or location of measurement - eyes open, eyes closed, EEG measured in healthy brain 
    region, EEG measured where the tumor was located, and, finally, the subject experiencing seizure 
    episode. To emphasize the distinction between positive and negative samples in terms of epilepsy, 
    We merge the first 4 classes into one and each time series sample has a binary label describing if 
    the associated subject is experiencing seizure or not. There are 11,500 EEG samples in total. 
    To evaluate the performance of pre-trained model on small fine-tuning dataset, we choose a tiny set 
    (60 samples; 30 samples for each class) for fine-tuning and assess the model with a validation set 
    (20 samples; 10 sample for each class). The model with best validation performance is use to make prediction 
    on test set (the remaining 11,420 samples). The raw dataset is distributed under the Creative Commons License (CC-BY) 
    4.0.
    '''
    TSeries_length = 178
    NB_channel = 1
    CLASSES = ['seizure state', 'no seizure state']

    def __init__(self, root=r'D:\repository\pycharm\datasets\time series\Epilepsy', mode='train', **kwargs):
        super(Epilepsy, self).__init__(root=root, mode=mode, series_length=Epilepsy.TSeries_length, **kwargs)
        self.classes = Epilepsy.CLASSES


class FD_A(TFCDataset):
    description = '''
    FD-A and FD-B are subsets taken from the FD dataset, which is gathered from an electromechanical drive system 
    that monitors the condition of rolling bearings and detects damages in them. There are four subsets of data 
    collected under various conditions, whose parameters include rotational speed, load torque, and radial force. 
    Each rolling bearing can be undamaged, inner damaged, and outer damaged, which leads to three classes in total. 
    We denote the subsets corresponding to condition A and condition B as Faulty Detection Condition A (FD-A) and 
    Faulty Detection Condition B (FD-B) , respectively. Each original recording has a single channel with sampling 
    frequency of 64k Hz and lasts 4 seconds. To deal with the long duration, we follow the procedure described by 
    Eldele et al., that is, we use sliding window length of 5,120 observations and a shifting length of either 
    1,024 or 4,096 to make the final number of samples relatively balanced between classes. The raw dataset is 
    distributed under the Creative Commons Attribution-Non Commercial 4.0 International License.
    '''
    TSeries_length = 5120
    NB_channel = 1

    CLASSES = ['Normal', 'Inner Fault', 'Outer Fault']

    def __init__(self, root=r'D:\repository\pycharm\datasets\time series\FD-A', mode='train', **kwargs):
        super(FD_A, self).__init__(root=root, mode=mode, series_length=FD_A.TSeries_length, **kwargs)
        self.classes = FD_A.CLASSES


class FD_B(TFCDataset):
    description = '''
    FD-A and FD-B are subsets taken from the FD dataset, which is gathered from an electromechanical drive system 
    that monitors the condition of rolling bearings and detects damages in them. There are four subsets of data 
    collected under various conditions, whose parameters include rotational speed, load torque, and radial force. 
    Each rolling bearing can be undamaged, inner damaged, and outer damaged, which leads to three classes in total. 
    We denote the subsets corresponding to condition A and condition B as Faulty Detection Condition A (FD-A) and 
    Faulty Detection Condition B (FD-B) , respectively. Each original recording has a single channel with sampling 
    frequency of 64k Hz and lasts 4 seconds. To deal with the long duration, we follow the procedure described by 
    Eldele et al., that is, we use sliding window length of 5,120 observations and a shifting length of either 
    1,024 or 4,096 to make the final number of samples relatively balanced between classes. The raw dataset is 
    distributed under the Creative Commons Attribution-Non Commercial 4.0 International License.
    '''
    TSeries_length = 5120
    CLASSES = ['Normal', 'Inner Fault', 'Outer Fault']

    def __init__(self, root=r'D:\repository\pycharm\datasets\time series\FD-B', mode='train', **kwargs):
        super(FD_B, self).__init__(root=root, mode=mode, series_length=FD_B.TSeries_length, **kwargs)
        self.classes = FD_B.CLASSES


class HAR(TFCDataset):
    description = '''
    HAR contains recordings of 30 health volunteers performing six daily activities such as walking, walking upstairs, 
    walking downstairs, sitting, standing, and laying. The prediction labels are the six activities. The wearable 
    sensors on a smartphone measure triaxial linear acceleration and triaxial angular velocity at 50 Hz. After 
    preprocessing and isolating out gravitational acceleration from body acceleration, there are nine channels in total. 
    To line up the semantic domain with the channels in the dataset use during fine-tuning Gesture we only use the three 
    channels of body linear accelerations. The raw dataset is distributed AS-IS and no responsibility implied or explicit 
    can be addressed to the authors or their institutions for its use or misuse. Any commercial use is prohibited.
    '''
    TSeries_length = 128
    CLASSES = ['Walking', 'Upstairs', 'Downstairs', 'Sitting', 'Standing', 'Laying']

    def __init__(self, root=r'D:\repository\pycharm\datasets\time series\HAR', mode='train', **kwargs):
        super(HAR, self).__init__(root=root, mode=mode, series_length=HAR.TSeries_length, **kwargs)
        self.classes = HAR.CLASSES


class Gesture(TFCDataset):
    description = '''
    Gesture contains accelerometer measurements of eight simple gestures that differed based on the paths of hand 
    movement. The eight gestures are: hand swiping left, right, up, down, hand waving in a counterclockwise circle, 
    or in clockwise circle, hand waving in a square, and waving a right arrow. The classification labels are those 
    eight different types of gestures. The original paper reports inclusion of 4,480 gesture measurements, but through 
    UCR Database we were only able to recover 440 measurements. The dataset is balanced with 55 samples each class and 
    is of a suitable size for our purpose of fine-tuning experiments. Sampling frequency is not explicitly reported in 
    the original paper but is presumably 100 Hz. The dataset uses three channels corresponding to three coordinate 
    directions of linear acceleration. The raw dataset is publicly available.
    '''
    TSeries_length = 206
    CLASSES = ['swiping left', 'swiping right', 'swiping up', 'swiping down',
               'waving counterclockwise', 'waving clockwise', 'waving square,',
               'waving right arrow']

    def __init__(self, root=r'D:\repository\pycharm\datasets\time series\Gesture', mode='train', **kwargs):
        super(Gesture, self).__init__(root=root, mode=mode, series_length=Gesture.TSeries_length, **kwargs)
        self.classes = Gesture.CLASSES


class ECG(TFCDataset):
    description = '''
    ECG is taken as a subset from the 2017 PhysioNet Challenge that focuses on ECG recording classification. The single 
    lead ECG measures four different underlying conditions of cardiac arrhythmias. More specifically, these classes 
    correspond to the recordings of normal sinus rhythm, atrial fibrillation (AF), alternative rhythm, or others 
    (too noisy to be classified). The recordings are sampled at 300 Hz. Furthermore, the dataset is imbalanced, 
    with much fewer samples from the atrial fibrillation and noisy classes out of all four. To preprocess the dataset, 
    we use the code from the CLOCS paper, which applied fixed-length window of 1,500 observations to divide up the long 
    recordings into short samples of 5 seconds in duration that is still physiologically meaningful. 
    The raw dataset is distributed under the Open Data Commons Attribution License v1.0.
    '''
    TSeries_length = 1500
    CLASSES = ['Normal', 'Atrial Fibrillation', 'Alternative Rhythm', 'Others']

    def __init__(self, root=r'H:\time series\ECG', mode='train', **kwargs):
        super(ECG, self).__init__(root=root, mode=mode, series_length=ECG.TSeries_length, **kwargs)
        self.classes = ECG.CLASSES


class EMG(TFCDataset):
    description = '''
    Electromyograms (EMG) measures muscle responses as electrical activity to neural stimulation, and they can be used 
    to diagnose certain muscular dystrophies and neuropathies. EMG consists of single-channel EMG recording from the 
    tibialis anterior muscle of three volunteers that are healthy, suffering from neuropathy, and suffering from myopathy, 
    respectively. The recordings are sampled with the frequency of 4K Hz. Each patient, i.e., their disorder, 
    is a separate classification category. Then the recordings are split into time series samples using a
    fixed-length window of 1,500 observations. The raw dataset is distributed under the Open Data Commons Attribution 
    License v1.0.
    '''
    TSeries_length = 1500
    CLASSES = ['Healthy', 'Neuropathy', 'Myopathy']

    def __init__(self, root=r'D:\repository\pycharm\datasets\time series\EMG', mode='train', **kwargs):
        super(EMG, self).__init__(root=root, mode=mode, series_length=EMG.TSeries_length, **kwargs)
        self.classes = EMG.CLASSES


