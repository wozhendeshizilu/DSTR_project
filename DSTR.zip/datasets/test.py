import AFT.datasets as datasets
import AFT.datasets.transform as T
import torch


if __name__ == '__main__':
    '''
    CricketX, UWaveGesture, InsectWingbeatSound, MFPT, DodgersLoopDay, DodgersLoopWeekend, DodgersLoopGame,
    "Train Size Evaluation Size	Test Size num of  num of  Length Freq (Hz)

    '''
    dataset_names = ['CWRU', 'ECG', 'JNU', 'MFPT', 'XJTU', 'ECG']
    # for dataset_name in dataset_names:
    #     dataset = datasets.__dict__[dataset_name]
    #     dataset_train = dataset(mode='train')
    #     dataset_eval = dataset(mode='val')
    #     dataset_tst = dataset(mode='test')
    #     sample = dataset_train[0][0]
    #
    #     details_str = '{}\t Train Size: {}\t Eval Size: {}\t Test Size: {}\t Channe: {}\t Class: {}\t Length: {}'.\
    #         format(dataset_name, len(dataset_train), len(dataset_eval), len(dataset_tst), sample.shape[0], len(dataset_train.CLASSES), sample.shape[-1])
    #     print(details_str)
    dataset = datasets.__dict__[dataset_names[0]]
    for mode in ['train', 'val', 'test']:
        dataset_ = dataset(mode=mode)
        num_label = len(dataset_.CLASSES)
        label = [0 for _ in range(num_label)]
        for samples, target in dataset_:
            label[target] += 1
        print(mode, label)
