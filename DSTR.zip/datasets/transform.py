import torch
import random
import numbers
import numpy as np
from torch import Tensor
from typing import Sequence
from torch.nn import functional as F
from torch.nn.functional import grid_sample, conv2d, conv1d, interpolate, pad as torch_pad
import warnings

import torchaudio.transforms as Taudio
import torchvision.transforms as Tvision

warnings.filterwarnings("ignore", category=DeprecationWarning)

__all__ = [
    'Compose',
    "Normalization",
    "GaussianNoise",
    "RandomResize",
    "VFlip",
    "HShift",
    "HFlip",
]


class Compose(Tvision.Compose):
    def __init__(self, transforms):
        super(Compose, self).__init__(transforms)


class RandomApply(Tvision.RandomApply):
    def __init__(self, transforms, p=0.2):
        super(RandomApply, self).__init__(transforms, p=p)


class Identity(torch.nn.Identity):
    def __init__(self):
        super(Identity, self).__init__()


class Normalization(torch.nn.Module):
    def __int__(self) -> None:
        super(Normalization, self).__int__()

    @torch.no_grad()
    def forward(self, x: Tensor) -> Tensor:
        _min, _ = torch.min(x, -1)
        _max, _ = torch.max(x, -1)
        _min, _max = _min[..., None], _max[..., None]
        return -1. + 2 * (x - _min) / (_max - _min + 1e-6)


class RandomResize(torch.nn.Module):

    def __init__(self, size: int) -> None:
        super(RandomResize, self).__init__()
        assert isinstance(size, (int, tuple, list))
        self.size_new = size

    @torch.no_grad()
    def forward(self, x: Tensor) -> Tensor:
        size_old = list(x for x in x.shape)
        if isinstance(self.size_new, int):
            self.size_new = size_old[:-1] + [self.size_new]

        x_new = torch.zeros(self.size_new, dtype=x.dtype)
        if size_old[-1] >= self.size_new[-1]:
            s_idx = random.randint(0, size_old[-1] - self.size_new[-1])
            x_new[:] = x[..., s_idx:s_idx + self.size_new[-1]]
        else:
            s_idx = random.randint(0, self.size_new[-1] - size_old[-1])
            x_new[..., s_idx:s_idx + size_old[-1]] = x
        return x_new


class CenterResize(torch.nn.Module):

    def __init__(self, size: int) -> None:
        super(CenterResize, self).__init__()
        assert isinstance(size, (int, tuple, list))
        self.size_new = size

    @torch.no_grad()
    def forward(self, x: Tensor) -> Tensor:
        size_old = list(x for x in x.shape)
        if isinstance(self.size_new, int):
            self.size_new = size_old[:-1] + [self.size_new]

        x_new = torch.zeros(self.size_new, dtype=x.dtype)
        if size_old[-1] >= self.size_new[-1]:
            s_idx = (size_old[-1] - self.size_new[-1]) // 2
            x_new[:] = x[..., s_idx:s_idx + self.size_new[-1]]
        else:
            s_idx = (self.size_new[-1] - size_old[-1]) // 2
            x_new[..., s_idx:s_idx + size_old[-1]] = x
        return x_new


class GaussianNoise(torch.nn.Module):
    """
    Single sample augment
    Args:
        snr (float): all pixels equal or above this value are inverted.
        p (float): probability of the image being color inverted. Default value is 0.5
    """

    def __init__(self, snr=20.) -> None:
        super().__init__()
        self.snr = snr

    @torch.no_grad()
    def forward(self, x):
        '''
        Returns: noise + x
        '''
        Ps = torch.sum(x ** 2, dim=0) / x.shape[-1]
        Pn = Ps / (10 ** (self.snr / 10))
        noise = torch.randn_like(x, device=x.device) * torch.sqrt(Pn).expand_as(x)
        return x + noise


class Scaling(torch.nn.Module):
    def __init__(self, sigma=0.1) -> None:
        super(Scaling, self).__init__()
        self.sigma = sigma

    def forward(self, x: Tensor) -> Tensor:
        factor = torch.normal(mean=1., std=self.sigma, size=(x.shape[0],))
        return factor * x


class VFlip(torch.nn.Module):
    """
    Single sample augment
    Args:
        snr (float): all pixels equal or above this value are inverted.
        p (float): probability of the image being color inverted. Default value is 0.5
    """

    def __init__(self) -> None:
        super().__init__()

    @torch.no_grad()
    def forward(self, x: Tensor) -> Tensor:
        x = x.clone()
        """
        Args:
            x:
        Returns:
            PIL Image or Tensor: Randomly solarized image.
        """
        return x.neg()


class HFlip(torch.nn.Module):
    """
    Single sample augment
    Args:
        snr (float): all pixels equal or above this value are inverted.
        p (float): probability of the image being color inverted. Default value is 0.5
    """

    def __init__(self) -> None:
        super().__init__()

    @torch.no_grad()
    def forward(self, x: Tensor) -> Tensor:
        x = x.clone()
        """
        Args:
            img (PIL Image or Tensor): Image to be solarized.

        Returns:
            PIL Image or Tensor: Randomly solarized image.
        """
        return x.flip(-1)


class HShift(torch.nn.Module):
    """
    Single sample augment
    Args:
        p (float): probability of the image being color inverted. Default value is 0.5
    """

    def __init__(self) -> None:
        super().__init__()

    @torch.no_grad()
    def forward(self, x: torch.Tensor) -> Tensor:
        x = x.clone()
        return torch.roll(x, random.randint(0, x.shape[-1]), dims=-1)


def make_mask(x: Tensor, start: int, end: int) -> Tensor:
    mask = torch.ones_like(x, device=x.device)
    if start <= end:
        mask[..., start: end] = 0.
    else:
        mask[..., :end] = mask[..., start:] = 0.
    return mask


class RandomTimeMasking(torch.nn.Module):
    """
    Single sample augment
    Random Crop consequent vector of length of size from original vector,  Cropped areas padded with zero
    Args:
        snr (float): all pixels equal or above this value are inverted.
        p (float): probability of the image being color inverted. Default value is 0.5
    """

    def __init__(self, min_time=100, max_time=500, p=0.25) -> None:
        super(RandomTimeMasking, self).__init__()
        self.min_time = min_time
        self.max_time = max_time
        self.p = p

    @torch.no_grad()
    def forward(self, x: Tensor) -> Tensor:
        x = x.clone()
        """
        Args:
            x:
        Returns:
            PIL Image or Tensor: Randomly solarized image.
        """
        b, w = x.shape[0], x.shape[-1]
        random_seed = torch.rand(b) < self.p
        masked_x = []
        for index in range(b):
            if not random_seed[index]:
                masked_x.append(x[index])
            else:
                time_mask = random.randint(self.min_time, self.max_time)
                time_start = random.randint(0, w)
                mask = make_mask(x[index], time_start, (time_start + time_mask) % w)
                masked_x.append(mask * x[index])
        return torch.stack(masked_x)


class VShift(torch.nn.Module):
    """
    Single sample augment
    Args:
        p (float): probability of the image being color inverted. Default value is 0.5
    """

    def __init__(self, p=0.5) -> None:
        super().__init__()
        self.p = p

    @torch.no_grad()
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.clone()
        _mean = torch.mean(x, dim=-1).unsqueeze(dim=-1)
        _max, _ = torch.max(torch.abs(x - _mean), dim=-1)
        random_seed = (torch.rand_like(_max, device=_max.device) < self.p).float()
        value_float = (torch.randn_like(_max, device=_max.device) * (_max / 2) * random_seed).unsqueeze(
            dim=-1).expand_as(
            x)
        return x + value_float


@DeprecationWarning
def _get_gaussian_kernel1d(kernel_size: int, sigma: float) -> Tensor:
    ksize_half = (kernel_size - 1) * 0.5

    x = torch.linspace(-ksize_half, ksize_half, steps=kernel_size)
    pdf = torch.exp(-0.5 * (x / sigma).pow(2))
    kernel1d = pdf / pdf.sum()

    return kernel1d


@DeprecationWarning
class Rotate(torch.nn.Module):
    """
    Single sample augment
    Args:
        snr (float): all pixels equal or above this value are inverted.
        p (float): probability of the image being color inverted. Default value is 0.5
        random rotate between +15 and -15 angle
    """

    def __init__(self, p=0.5, max_angle=5, rotate_loc=None) -> None:
        super().__init__()
        self.p = p
        self.x = None
        self.max_angle = max_angle
        self.rotate_loc = rotate_loc

    @torch.no_grad()
    def forward(self, y):
        """
        Args:
            img (PIL Image or Tensor): Image to be solarized.

        Returns:
            PIL Image or Tensor: Randomly solarized image.
        """
        if random.uniform(0, 1) < self.p:
            # if self.rotate_loc is None:
            # self.rotate_loc = torch.randint(0, y.shape[-1], (1,)).item()
            rotate_loc = random.randint(0, y.shape[-1])
            if self.x is None:
                self.x = torch.arange(0 - rotate_loc, y.shape[-1] - rotate_loc, device=y.device).expand_as(y)
            random_angle = (torch.pi * 2 / 360 * self.max_angle * torch.rand(1, device=y.device)).expand_as(y)
            return self.x * torch.sin(random_angle) + y * torch.cos(random_angle)
        else:
            return y


@DeprecationWarning
class GaussianBlur(torch.nn.Module):
    """Blurs image with randomly chosen Gaussian blur.
    If the image is torch Tensor, it is expected
    to have [..., C, H, W] shape, where ... means an arbitrary number of leading dimensions.

    Args:
        kernel_size (int or sequence): Size of the Gaussian kernel.
        sigma (float or tuple of float (min, max)): Standard deviation to be used for
            creating kernel to perform blurring. If float, sigma is fixed. If it is tuple
            of float (min, max), sigma is chosen uniformly at random to lie in the
            given range.

    Returns:
        PIL Image or Tensor: Gaussian blurred version of the input image.

    """

    def __init__(self, kernel_size, p, sigma=(0.1, 2.0)) -> None:
        super().__init__()
        self.p = p
        self.kernel_size = kernel_size
        if self.kernel_size <= 0 or self.kernel_size % 2 == 0:
            raise ValueError("Kernel size value should be an odd and positive number.")

        if isinstance(sigma, numbers.Number):
            if sigma <= 0:
                raise ValueError("If sigma is a single number, it must be positive.")
            sigma = (sigma, sigma)
        elif isinstance(sigma, Sequence) and len(sigma) == 2:
            if not 0.0 < sigma[0] <= sigma[1]:
                raise ValueError("sigma values should be positive and of the form (min, max).")
        else:
            raise ValueError("sigma should be a single number or a list/tuple with length 2.")

        self.sigma = sigma

    @staticmethod
    def get_params(sigma_min: float, sigma_max: float) -> float:
        """Choose sigma for random gaussian blurring.

        Args:
            sigma_min (float): Minimum standard deviation that can be chosen for blurring kernel.
            sigma_max (float): Maximum standard deviation that can be chosen for blurring kernel.

        Returns:
            float: Standard deviation to be passed to calculate kernel for gaussian blurring.
        """
        return torch.empty(1).uniform_(sigma_min, sigma_max).item()

    @torch.no_grad()
    def forward(self, img: Tensor) -> Tensor:
        """
        Args:
            img (PIL Image or Tensor): image to be blurred.

        Returns:
            PIL Image or Tensor: Gaussian blurred image
        """
        if random.uniform(0, 1) <= self.p:
            sigma = self.get_params(self.sigma[0], self.sigma[1])
            kernel = _get_gaussian_kernel1d(self.kernel_size, sigma)
            kernel = kernel.expand(1, 1, 1, self.kernel_size).to(img.device)
            padding = [self.kernel_size // 2, self.kernel_size // 2, 0, 0]
            img = torch_pad(img, padding, mode="reflect")
            img = conv2d(img, kernel, groups=img.shape[-3])
            return img
        else:
            return img

    def __repr__(self) -> str:
        s = f"{self.__class__.__name__}(kernel_size={self.kernel_size}, sigma={self.sigma})"
        return s


# @DeprecationWarning
def resize(input,
           size=None,
           scale_factor=None,
           mode='nearest',
           align_corners=None,
           warning=True):
    if warning:
        if size is not None and align_corners:
            input_h, input_w = tuple(int(x) for x in input.shape[2:])
            output_h, output_w = tuple(int(x) for x in size)
            if output_h > input_h or output_w > output_h:
                if ((output_h > 1 and output_w > 1 and input_h > 1
                     and input_w > 1) and (output_h - 1) % (input_h - 1)
                        and (output_w - 1) % (input_w - 1)):
                    warnings.warn(
                        f'When align_corners={align_corners}, '
                        'the output would more aligned if '
                        f'input size {(input_h, input_w)} is `x+1` and '
                        f'out size {(output_h, output_w)} is `nx+1`')
    return F.interpolate(input, size, scale_factor, mode, align_corners)


class TimeMasking(torch.nn.Module):
    def __init__(self, block_size, p, vflip_p, hflip_p, vshift_p, hshift_p, gau_snr=25, gau_p=0.,
                 re_norm=False) -> None:
        super(TimeMasking, self).__init__()

        self.block_size = block_size
        self.ratio = p

        self.transform = Compose(
            [
                VFlip(vflip_p),
                HFlip(hflip_p),
                VShift(vshift_p),
                HShift(hshift_p),
                GaussianNoise(gau_snr, gau_p)
            ]
        )
        if re_norm: self.transform.transforms.append(Normalization())

    @torch.no_grad()
    def forward(self, x: torch.Tensor) -> Tensor:
        x = x.clone()
        x = self.transform(x)
        B, W = 1 if x.ndim < 4 else x.shape[0], x.shape[-1]
        mshape = B, 1, round(W / self.block_size)
        time_mask = torch.rand(mshape, device=x.device)
        time_mask = (time_mask > self.ratio).float()
        time_mask = resize(time_mask, size=W)
        if x.ndim > 3:
            time_mask = time_mask.unsqueeze(dim=-3)
        time_mask = time_mask.expand_as(x)
        return x * time_mask.view_as(x)


@DeprecationWarning
class Resample(torch.nn.Module):
    def __init__(
            self,
            orig_freq: int = 12000,
            resampling_method: str = "sinc_interpolation",
            lowpass_filter_width: int = 6,
            rolloff: float = 0.99,
    ) -> None:
        super().__init__()
        self.orig_freq = orig_freq
        self.resample_method = resampling_method
        self.lowpass_filter_width = lowpass_filter_width
        self.rolloff = rolloff

    def forward(self, x: Tensor) -> Tensor:
        b = x.shape[0]
        resampled_x = []
        # 512 < resample_ratio / self.orig_freq * 1024 < 1536 ->
        random_seed = torch.rand(b, device=x.device) * 0.4 + 0.8
        for index in range(b):
            resample_x_index = Taudio.Resample(self.orig_freq, (self.orig_freq * random_seed[index]).int())(x[index])
            resampled_x.append(resample_x_index if random_seed[index] >= 1. else torch.cat(
                (resample_x_index, resample_x_index.flip(-1)), dim=-1))
        return torch.stack(resampled_x)


class MaskingGenerator:
    # https://arxiv.org/pdf/2203.12602.pdf

    def __init__(self, nb_patches: int, mask_ratio: float) -> None:
        self.nb_mask_patches = int(mask_ratio * nb_patches)
        self.nb_unmask_patches = nb_patches - self.nb_mask_patches

    def __call__(self, x: Tensor):
        mask_batch = []
        for _ in range(x.shape[0]):
            mask_per_sample = np.hstack([
                np.ones(self.nb_mask_patches),
                np.zeros(self.nb_unmask_patches),
            ])
            np.random.shuffle(mask_per_sample)
            mask_batch.append(mask_per_sample)
        return torch.from_numpy(np.stack(mask_batch))
