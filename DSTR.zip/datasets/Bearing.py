import os
import torch
from datasets import utils
from datasets.SensorDataset import TSeriesDataset

__all__ = ['JNU', 'CWRU']


class BearingDataset(TSeriesDataset):
    modes = ['train', 'val', 'test']

    def __init__(self, root, mode='train', subset=False, **kwargs):
        assert mode in 'train' or 'test' or 'val', f'{mode} is not acceptable'
        f = os.path.join(root, f'{mode}.pt')
        _data = torch.load(f)
        _x, _y = _data["samples"], _data["targets"]

        import numpy as np

        # y = _y.cpu().numpy()
        # print("mode:", mode)
        # print("all labels:", np.bincount(y.reshape(-1)))
        # print("total labels:", np.bincount(y.reshape(-1)).sum())
        # print("x shape:", _x.shape)

        # subset
        if subset:
            _x = _x[:4000]
            _y = _y[:4000]
        super(BearingDataset, self).__init__(_x, _y, **kwargs)


class CWRU(BearingDataset):

    TSeries_length = 1024
    Name_Clz_dict = {
        '0.007-Ball': 0, '0.007-InnerRace': 1, '0.007-OuterRace3': 2, '0.007-OuterRace6': 3, '0.007-OuterRace12': 4,
        '0.014-Ball': 5, '0.014-InnerRace': 6, '0.014-OuterRace3': 7, '0.014-OuterRace6': 8,
        '0.021-Ball': 9, '0.021-InnerRace': 10, '0.021-OuterRace3': 11, '0.021-OuterRace6': 12,
        '0.021-OuterRace12': 13,
        '0.028-Ball': 14, '0.028-InnerRace': 15, 'Normal': 16}
    CLASSES = Name_Clz_dict.keys()

    def __init__(self, root=r'H:\time series\bearing\cwru', mode='train', **kwargs):
        super(CWRU, self).__init__(root=root, mode=mode, **kwargs)
        self.classes = CWRU.CLASSES


class JNU(BearingDataset):

    TSeries_length = 1024
    Name_Clz_dict = {
        'n600.csv': 0, 'n800.csv': 0, 'n1000.csv': 0,
        'ib600.csv': 1, 'ib800.csv': 1, 'ib1000.csv': 1,
        'ob600.csv': 2, 'ob800.csv': 2, 'ob1000.csv': 2,
        'tb600.csv': 3, 'tb800.csv': 3, 'tb1000.csv': 3,
    }
    CLASSES = ['Normal Condition', 'Inner Ball', 'Outer Fault', 'Ball Fault']

    def __init__(self, root=r'H:\time series\bearing\jnu', mode='train', **kwargs):
        super(JNU, self).__init__(root=root, mode=mode, **kwargs)
        self.classes = JNU.CLASSES
