# -*- coding: utf-8 -*-
import torch
import numpy as np
import torch.utils.data as data
from sklearn import preprocessing
from .SensorDataset import TSeriesDataset


def nb_classes(dataset):
    if dataset == 'MFPT':
        return 15
    if dataset == 'XJTU':
        return 15
    if dataset == "CricketX":
        return 12  # 300
    if dataset == "UWaveGestureLibraryAll":
        return 8  # 945
    if dataset == "DodgerLoopDay":
        return 7
    if dataset == "InsectWingbeatSound":
        return 11


def nb_dims(dataset):
    if dataset in ["unipen1a", "unipen1b", "unipen1c"]:
        return 2
    return 1


def set_nan_to_zero(a):
    where_are_NaNs = np.isnan(a)
    a[where_are_NaNs] = 0
    return a


def TSC_data_loader(dataset_path, dataset_name):
    print("[INFO] {}".format(dataset_name))

    Train_dataset = np.loadtxt(
        dataset_path + '/' + dataset_name + '/' + dataset_name + '_TRAIN.tsv')
    Test_dataset = np.loadtxt(
        dataset_path + '/' + dataset_name + '/' + dataset_name + '_TEST.tsv')
    Train_dataset = Train_dataset.astype(np.float32)
    Test_dataset = Test_dataset.astype(np.float32)

    X_train = Train_dataset[:, 1:]
    y_train = Train_dataset[:, 0:1]

    X_test = Test_dataset[:, 1:]
    y_test = Test_dataset[:, 0:1]
    le = preprocessing.LabelEncoder()
    le.fit(np.squeeze(y_train, axis=1))
    y_train = le.transform(np.squeeze(y_train, axis=1))
    y_test = le.transform(np.squeeze(y_test, axis=1))
    return set_nan_to_zero(X_train), y_train, set_nan_to_zero(X_test), y_test


def load_ucr2018(dataset_path, dataset_name):
    ##################
    # load raw data
    ##################
    nb_class = nb_classes(dataset_name)
    nb_dim = nb_dims(dataset_name)

    if dataset_name in ['MFPT', 'XJTU']:
        x = np.load("{}/{}/{}_data.npy".format(dataset_path, dataset_name, dataset_name))
        y = np.load("{}/{}/{}_label.npy".format(dataset_path, dataset_name, dataset_name))

        (x_train, x_test) = (x[:100], x[100:])
        (y_train, y_test) = (y[:100], y[100:])

    else:
        x_train, y_train, x_test, y_test = TSC_data_loader(dataset_path, dataset_name)

    nb_timesteps = int(x_train.shape[1] / nb_dim)
    input_shape = (nb_timesteps, nb_dim)

    ############################################
    # Combine all train and test data for resample
    ############################################

    x_all = np.concatenate((x_train, x_test), axis=0)
    y_all = np.concatenate((y_train, y_test), axis=0)
    ts_idx = list(range(x_all.shape[0]))
    np.random.shuffle(ts_idx)
    x_all = x_all[ts_idx]
    y_all = y_all[ts_idx]

    label_idxs = np.unique(y_all)
    class_stat_all = {}
    for idx in label_idxs:
        class_stat_all[idx] = len(np.where(y_all == idx)[0])
    print("[Stat] All class: {}".format(class_stat_all))

    test_idx = []
    val_idx = []
    train_idx = []
    for idx in label_idxs:
        target = list(np.where(y_all == idx)[0])
        nb_samp = int(len(target))
        test_idx += target[:int(nb_samp * 0.25)]
        val_idx += target[int(nb_samp * 0.25):int(nb_samp * 0.5)]
        train_idx += target[int(nb_samp * 0.5):]

    x_test = x_all[test_idx]
    y_test = y_all[test_idx]
    x_val = x_all[val_idx]
    y_val = y_all[val_idx]
    x_train = x_all[train_idx]
    y_train = y_all[train_idx]

    label_idxs = np.unique(y_train)
    class_stat = {}
    for idx in label_idxs:
        class_stat[idx] = len(np.where(y_train == idx)[0])
    # print("[Stat] Train class: {}".format(class_stat))
    print("[Stat] Train class: mean={}, std={}".format(np.mean(list(class_stat.values())),
                                                       np.std(list(class_stat.values()))))

    label_idxs = np.unique(y_val)
    class_stat = {}
    for idx in label_idxs:
        class_stat[idx] = len(np.where(y_val == idx)[0])
    # print("[Stat] Test class: {}".format(class_stat))
    print("[Stat] Val class: mean={}, std={}".format(np.mean(list(class_stat.values())),
                                                     np.std(list(class_stat.values()))))

    label_idxs = np.unique(y_test)
    class_stat = {}
    for idx in label_idxs:
        class_stat[idx] = len(np.where(y_test == idx)[0])
    # print("[Stat] Test class: {}".format(class_stat))
    print("[Stat] Test class: mean={}, std={}".format(np.mean(list(class_stat.values())),
                                                      np.std(list(class_stat.values()))))

    ########################################
    # Data Split End
    ########################################

    # Process data
    x_test = x_test.reshape((-1, input_shape[0], input_shape[1]))
    x_val = x_val.reshape((-1, input_shape[0], input_shape[1]))
    x_train = x_train.reshape((-1, input_shape[0], input_shape[1]))

    print("Train:{}, Test:{}, Class:{}".format(x_train.shape, x_test.shape, nb_class))

    # Normalize
    x_train_max = np.max(x_train)
    x_train_min = np.min(x_train)
    x_train = 2. * (x_train - x_train_min) / (x_train_max - x_train_min) - 1.
    # Test is secret
    x_val = 2. * (x_val - x_train_min) / (x_train_max - x_train_min) - 1.
    x_test = 2. * (x_test - x_train_min) / (x_train_max - x_train_min) - 1.

    return x_train, y_train, x_val, y_val, x_test, y_test, nb_class, class_stat_all


class SelfTimeDataset(TSeriesDataset):
    # https://arxiv.org/abs/2011.13548
    modes = ['train', 'val', 'test']

    def __init__(self, f: str, dataset_name, mode='train', **kwargs):
        assert mode in SelfTimeDataset.modes
        _x_train, _y_train, _x_val, _y_val, _x_test, _y_test, nb_class, _ = load_ucr2018(f, dataset_name)
        if mode == 'train':
            samples, targets = torch.from_numpy(_x_train), torch.from_numpy(_y_train)
        elif mode == 'val':
            samples, targets = torch.from_numpy(_x_val), torch.from_numpy(_y_val)
        else:
            samples, targets = torch.from_numpy(_x_test), torch.from_numpy(_y_test)
        samples = samples.permute(0, -1, -2).type(torch.float32)
        super(SelfTimeDataset, self).__init__(samples, targets, **kwargs)


class CricketX(SelfTimeDataset):
    # http://www.timeseriesclassification.com/description.php?Dataset=CricketX

    description = '''
        The series Cricket X, Y and Z are accelerometer data (in three dimensions) taken from actors performing cricket 
        gestures. The twelve classes are different umpire signals: Cancel Call, Dead Ball, Four, Last Hour Leg Bye, 
        No Ball, One Short, Out, Penalty Runs, Six, TV Replay, and Wide. They mounted two accelerometers orthogonal to 
        each other, thus acceleration is measured in 3D space. The accelerometers are housed in a small wrist watch 
        sized enclosure worn in the form of a wrist band. Taken together the data is a multivariate time series 
        classification problem, but the series are not aligned so in its current format cannot be used as such 
        Originally used in Ko et al. "Online Context Recognition in Multisensor Systems using Dynamic Time Warping
        '''
    TSeries_length = 288
    train_size = 390
    test_size = 390
    series_length = 300
    CLASSES = ['Cancel Call', 'Dead Ball', 'Four', 'Last Hour', 'Leg Bye', 'No Ball', 'One Short', 'Out',
               'Penalty Runs', 'Six', 'TV Replay', 'Wide']

    def __init__(self, f=r'D:\repository\pycharm\datasets\time series', mode='train', **kwargs):
        super(CricketX, self).__init__(f, 'CricketX', mode, **kwargs)


class UWaveGesture(SelfTimeDataset):
    # http://www.timeseriesclassification.com/description.php?Dataset=UWaveGestureLibraryAll
    description = '''
        A set of eight simple hand-moving gestures generated from accelerometers. First described in the paper 
        "uWave: Accelerometer-based personalized gesture recognition and its applications".
        '''
    TSeries_length = 928
    train_size = 896
    test_size = 3582
    series_length = 945
    CLASSES = ['Down then left', 'square Clockwise', 'Right', 'Left', 'Up', 'Down', 'Circles clockwise',
               'Circles counterclockwise']

    def __init__(self, f=r'D:\repository\pycharm\datasets\time series', mode='train', **kwargs):
        super(UWaveGesture, self).__init__(f, 'UWaveGestureLibraryAll', mode, **kwargs)


class InsectWingbeatSound(SelfTimeDataset):
    # http://www.timeseriesclassification.com/description.php?Dataset=InsectWingbeatSound
    description = '''
        The data were generated by the UCR computational entomology group and used in [1]. 
        The data are power spectrum of the sound of insects passing through a sensor. 
        The 11 classes are male and female mosquitos (Ae. aegypti, Cx. tarsalis, Cx. quinquefasciants, Cx. stigmatosoma), 
        two types of flies (Musca domestica and Drosophila simulans) and other insects. More details about the conditions 
        under which the data were collected are available in [1] and [2].
        '''
    TSeries_length = 256
    train_size = 896
    test_size = 3582
    series_length = 256
    CLASSES = [_idx for _idx in range(8)]

    def __init__(self, f=r'D:\repository\pycharm\datasets\time series', mode='train', **kwargs):
        super(InsectWingbeatSound, self).__init__(f, 'InsectWingbeatSound', mode, **kwargs)


class MFPT(SelfTimeDataset):
    # https://www.mfpt.org/
    description = '''
        The data were generated by the UCR computational entomology group and used in [1]. 
        The data are power spectrum of the sound of insects passing through a sensor. 
        The 11 classes are male and female mosquitos (Ae. aegypti, Cx. tarsalis, Cx. quinquefasciants, Cx. stigmatosoma), 
        two types of flies (Musca domestica and Drosophila simulans) and other insects. More details about the conditions 
        under which the data were collected are available in [1] and [2].
        '''
    TSeries_length = 1024
    train_size = 2574
    test_size = 0
    series_length = 1024
    CLASSES = [_idx for _idx in range(15)]

    def __init__(self, f=r'H:\time series', mode='train', **kwargs):
        super(MFPT, self).__init__(f, 'MFPT', mode, **kwargs)


class XJTU(SelfTimeDataset):
    # https://www.mfpt.org/
    description = '''
        The data were generated by the UCR computational entomology group and used in [1]. 
        The data are power spectrum of the sound of insects passing through a sensor. 
        The 11 classes are male and female mosquitos (Ae. aegypti, Cx. tarsalis, Cx. quinquefasciants, Cx. stigmatosoma), 
        two types of flies (Musca domestica and Drosophila simulans) and other insects. More details about the conditions 
        under which the data were collected are available in [1] and [2].
        '''
    TSeries_length = 1024
    train_size = 1920
    test_size = 0
    series_length = 1024
    CLASSES = [_idx for _idx in range(15)]

    def __init__(self, f=r'H:\time series', mode='train', **kwargs):
        super(XJTU, self).__init__(f, 'XJTU', mode, **kwargs)


class DodgersLoopDay(SelfTimeDataset):
    # https://archive.ics.uci.edu/ml/datasets/Dodgers+Loop+Sensor
    description = '''
        The traffic data are collected with the loop sensor installed on ramp for the 101 North freeway in Los Angeles. 
        This location is close to Dodgers Stadium; therefore the traffic is affected by volumne of visitors to 
        the stadium.
        '''
    TSeries_length = 288
    train_size = 78
    test_size = 80
    series_length = 288
    CLASSES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

    def __init__(self, f=r'D:\repository\pycharm\datasets\time series', mode='train', **kwargs):
        super(DodgersLoopDay, self).__init__(f, 'DodgerLoopDay', mode, **kwargs)


class DodgersLoopWeekend(SelfTimeDataset):
    # https://archive.ics.uci.edu/ml/datasets/Dodgers+Loop+Sensor
    description = '''
        The traffic data are collected with the loop sensor installed on ramp for the 101 North freeway in Los Angeles. 
        This location is close to Dodgers Stadium; therefore the traffic is affected by volumne of visitors to 
        the stadium.
        '''
    TSeries_length = 1024
    train_size = 2574
    test_size = 0
    series_length = 1024
    CLASSES = ['Weekday', 'Weekend']

    def __init__(self, f=r'D:\repository\pycharm\datasets\time series', mode='train', **kwargs):
        super(DodgersLoopWeekend, self).__init__(f, 'DodgerLoopDay', mode, **kwargs)


class DodgersLoopGame(SelfTimeDataset):
    # https://archive.ics.uci.edu/ml/datasets/Dodgers+Loop+Sensor
    description = '''
        The traffic data are collected with the loop sensor installed on ramp for the 101 North freeway in Los Angeles. 
        This location is close to Dodgers Stadium; therefore the traffic is affected by volumne of visitors to 
        the stadium.
        '''
    TSeries_length = 1024
    train_size = 2574
    test_size = 0
    series_length = 1024
    CLASSES = ['Normal day', 'Game day']

    def __init__(self, f=r'D:\repository\pycharm\datasets\time series', mode='train', **kwargs):
        super(DodgersLoopGame, self).__init__(f, 'DodgerLoopDay', mode, **kwargs)


