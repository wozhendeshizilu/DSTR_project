import matplotlib.pyplot as plt
from scipy.interpolate import make_interp_spline
import torch, numpy as np, pandas as pd

import json

f_mask = r'./logs/0.6-log.txt'
f_unmask = r'./logs/0.0-log.txt'

loss_mask = []
loss_unmask = []

e_idx = 200
x_label = [_ for _ in range(e_idx)]
with open(f_mask, 'r') as F:
    for idx in range(0, e_idx):
        _str = F.readline()
        _dict = json.loads(_str)
        loss_mask += [_dict['train_loss']]

with open(f_unmask, 'r') as F:
    for idx in range(0, e_idx):
        _str = F.readline()
        _dict = json.loads(_str)
        loss_unmask += [_dict['train_loss']]

fig, axes = plt.subplots(nrows=1, ncols=1, figsize=(7.8, 3.5))
axe1 = axes

axe1.spines['right'].set_visible(False)
axe1.spines['top'].set_visible(False)

axe1.set_xlabel("Epochs (%)", fontsize=10)
axe1.set_ylabel("Train Loss (MSE)", fontsize=10)
axe1.title.set_size(14)
axe1.plot(x_label, loss_mask, markersize=4, label='mask')
axe1.plot(x_label, loss_unmask, markersize=4, label='unmask')
leg = axe1.legend(fancybox=True, shadow=True)

plt.tight_layout()
plt.savefig(r'./figs/loss_mask_vs_unmask.pdf')
plt.show()
