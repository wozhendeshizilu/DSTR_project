import matplotlib.pyplot as plt
from scipy.interpolate import make_interp_spline
import torch, numpy as np, pandas as pd

fig, axes = plt.subplots(nrows=2, ncols=1, figsize=(8, 4.5))
(axe1), (axe2) = axes

x_label = []
for i in [_ for _ in range(1, 6)][::2]:
    for j in [_ for _ in range(1, 6)][::2]:
        x_label.append('{}_{}'.format(i, j))
linprobe_label = [36.353, 76.127, 75.545, 74.043, 85.202, 84.881, 74.164, 85.332, 83.378]
finetune_label = [96.822, 97.534, 97.178, 96.405, 97.108, 97.178, 96.865, 96.839, 96.743]

axe1.spines['right'].set_visible(False)
axe1.spines['top'].set_visible(False)

axe1.set_xlabel("Depth of Decoder [Real_Imag]", fontsize=10)
axe1.set_ylabel("Accuracy (%)", fontsize=10)
axe1.title.set_size(14)
axe1.title.set_text('Linear probing')
axe1.plot(x_label, linprobe_label, marker='o', markersize=3)
# axe1.set_xticklabels(sensit_data[:, 0].astype(str).tolist())
lab_float_linear_probing = [2, 2, 2, 2, -8, -8, 4, 2, 2]
for idx, (x, y) in enumerate(zip(x_label, linprobe_label)):
    axe1.text(x, y + lab_float_linear_probing[idx], '%.3f' % y, ha='center', fontdict={'fontsize': 10})

axe2.spines['right'].set_visible(False)
axe2.spines['top'].set_visible(False)

axe2.set_xlabel("Depth of Decoder [Real_Imag]", fontsize=10)
axe2.set_ylabel("Accuracy (%)", fontsize=10)
axe2.title.set_size(14)
axe2.title.set_text('Fine-tuning')
axe2.plot(x_label, finetune_label, marker='o', markersize=3)
# axe2.set_xticklabels(conver_iter_data[:, 0].astype(str).tolist())

lab_float_fine_tuning = [0.1, 0.05, 0.1, 0.2, 0.1, 0.07, 0.1, 0.07, 0.07]
for idx, (x, y) in enumerate(zip(x_label, finetune_label)):

    axe2.text(x, y + lab_float_fine_tuning[idx], '%.3f' % y, ha='center', fontdict={'fontsize': 10})

plt.tight_layout()
plt.savefig(r'./figs/depth_decoder.pdf')
plt.show()
