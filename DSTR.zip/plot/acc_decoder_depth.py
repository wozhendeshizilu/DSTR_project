import matplotlib.pyplot as plt
from scipy.interpolate import make_interp_spline
import torch, numpy as np, pandas as pd

fig, axes = plt.subplots(nrows=2, ncols=1, figsize=(8, 4.5))
(axe1), (axe2) = axes

x_label = [i * 10 for i in range(10)]
linprobe_label = [31.09, 44.785, 59.149, 67.312, 76.891, 85.202, 88.867, 87.66, 81.824, 77.794]
finetune_label = [93.634, 94.876, 97.056, 96.344, 96.162, 97.108, 97.829, 97.681, 97.273, 96.552]

axe1.spines['right'].set_visible(False)
axe1.spines['top'].set_visible(False)

axe1.set_xlabel("Mask Ratio (%)", fontsize=10)
axe1.set_ylabel("Accuracy (%)", fontsize=10)
axe1.title.set_size(14)
axe1.title.set_text('Linear probing')
axe1.plot(x_label, linprobe_label, marker='o', markersize=3)
# axe1.set_xticklabels(sensit_data[:, 0].astype(str).tolist())
for x, y in zip(x_label, linprobe_label):
    axe1.text(x, y + 2, '%.3f' % y, ha='center', fontdict={'fontsize': 10})

axe2.spines['right'].set_visible(False)
axe2.spines['top'].set_visible(False)

axe2.set_xlabel("Mask Ratio (%)", fontsize=10)
axe2.set_ylabel("Accuracy (%)", fontsize=10)
axe2.title.set_size(14)
axe2.title.set_text('Fine-tune')
axe2.plot(x_label, finetune_label, marker='o', markersize=3)
# axe2.set_xticklabels(conver_iter_data[:, 0].astype(str).tolist())
for x, y in zip(x_label, finetune_label):
    axe2.text(x, y + 0.3, '%.3f' % y, ha='center', fontdict={'fontsize': 10})

plt.tight_layout()
plt.savefig(r'./figs/mask_ratio_ablation.pdf')
plt.show()
